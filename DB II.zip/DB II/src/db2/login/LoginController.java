package db2.login;

import java.io.IOException;

import db2.DBManager;
import db2.main.MainController;
import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.animation.SequentialTransition;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Duration;

public class LoginController
{
	@FXML
	private TextField username;
	
	@FXML
	private PasswordField password;
	
	@FXML
	private Button login;
	
	@FXML
	private VBox disable;
	
	@FXML
	private ProgressIndicator progress;
	
	@FXML
	private Label loginFailMsg;
	
	public void initialize()
	{
		username.textProperty().addListener((event)->login.setDisable(username.getText().isEmpty()||password.getText().isEmpty()));
		password.textProperty().addListener((event)->login.setDisable(username.getText().isEmpty()||password.getText().isEmpty()));
		EventHandler<ActionEvent> loginHandler = (event)->
		{
			disable.setDisable(true);
			progress.setVisible(true);
			Thread thread = new Thread()
			{
				public void run()
				{
					String name = DBManager.login(username.getText(), password.getText());
					Platform.runLater(()->
					{
						disable.setDisable(false);
						progress.setVisible(false);
					});
					if(name != null)
					{
						Platform.runLater(()->
						{
							try
							{
								FXMLLoader loader = new FXMLLoader(getClass().getResource("../main/main.fxml"));
								MainController mainController = new MainController(name);
								loader.setController(mainController);
								Scene scene = new Scene(loader.load(), login.getScene().getWidth(), login.getScene().getHeight());
								scene.getStylesheets().add(getClass().getResource("../main/main.css").toExternalForm());
								((Stage)login.getScene().getWindow()).setScene(scene);
							}
							catch(IOException e)
							{
								e.printStackTrace();
							}
						});
					}
					else
					{
						Platform.runLater(()->
						{
							loginFailMsg.setVisible(true);
							FadeTransition fadeOut = new FadeTransition(Duration.millis(1000), loginFailMsg);
							fadeOut.setFromValue(1.0);
							fadeOut.setToValue(0.0);
							SequentialTransition seqTransition = new SequentialTransition(new PauseTransition(Duration.millis(3000)), fadeOut);
							seqTransition.setOnFinished((event)->loginFailMsg.setVisible(false));
							seqTransition.play();
						});
					}
				}
			};
			thread.setDaemon(true);
			thread.start();
		};
		login.setOnAction(loginHandler);
		password.setOnAction(loginHandler);
		username.setOnAction(loginHandler);
	}
}