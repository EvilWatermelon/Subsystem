package db2.main;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TabPane;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

public class MainController
{
	private String name;
	
	@FXML
	private Button logout;
	
	@FXML
	private TabPane tabs;
	
	@FXML
	private Label managerName;
	
	@FXML
	private WebView webView;
	
	public MainController(String name)
	{
		this.name = name;
	}

	public void initialize()
	{
		managerName.setText(name);
		tabs.widthProperty().addListener((observable, oldV, newV) ->
		{
            int numTabs = tabs.getTabs().size();
        	tabs.setTabMinWidth(newV.intValue()/numTabs-20);
        	tabs.setTabMaxWidth(newV.intValue()/numTabs-20);
        });
		webView.getEngine().load("http://generix.esy.es/db2/index.html");
		logout.setOnAction((event)->
		{
			try
			{
				Scene scene = new Scene(FXMLLoader.load(getClass().getResource("../login/login.fxml")), logout.getScene().getWidth(), logout.getScene().getHeight());
				scene.getStylesheets().add(getClass().getResource("../login/login.css").toExternalForm());
				((Stage)logout.getScene().getWindow()).setScene(scene);
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
		});
	}
}