package db2;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.xml.bind.DatatypeConverter;

public class DBManager
{
	private static final String DB_URL = "jdbc:oracle:thin:@studidb.gm.fh-koeln.de:1521:VLESUNG"; //jdbc:mysql://sql11.freesqldatabase.com:3306/sql11175701?autoReconnect=true&useSSL=false
	private static final String DB_USER = "ORA_AI_2_3"; //sql11175701
	private static final String DB_PASS = "vRNAvbtXSvIB"; //nHHfZkV96F
	
	static
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Class.forName("com.mysql.jdbc.Driver");
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
	}
	
	public static String login(String username, String password)
	{
		try(Connection connection = DriverManager.getConnection(DB_URL,DB_USER,DB_PASS))
		{
			try
			{
				PreparedStatement stmnt = connection.prepareStatement("SELECT * FROM Manager WHERE username = ?");
				stmnt.setString(1, username);
				ResultSet result = stmnt.executeQuery();
				if(result.next())
				{
					String salt = result.getString("salt");
					String newHash = DatatypeConverter.printHexBinary(MessageDigest.getInstance("SHA-256").digest((salt+password+salt).getBytes()));
					if(newHash.equals(result.getString("hash")))
					{
						String lastname = result.getString("name");
						lastname = lastname.substring(lastname.lastIndexOf(" "));
						return (result.getString("sex").equals("m")?"Herr":"Frau")+lastname;
					}
				}
				else
					return null;
			}
			catch(SQLException | NoSuchAlgorithmException e)
			{
				e.printStackTrace();
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}
}